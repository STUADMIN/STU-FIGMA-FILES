
  # Recreate Figma File

  This is a code bundle for Recreate Figma File. The original project is available at https://www.figma.com/design/uzw78kikH4SOfYiVykqA6I/Recreate-Figma-File.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  