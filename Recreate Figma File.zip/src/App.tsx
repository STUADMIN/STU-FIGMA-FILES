import TendersAshwellGate from "./imports/TendersAshwellGate";

export default function App() {
  return <TendersAshwellGate />;
}
