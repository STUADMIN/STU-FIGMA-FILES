import svgPaths from "./svg-gcw148om8q";

function Group1() {
  return (
    <div className="absolute h-[71.003px] left-[19.74px] top-[28.04px] w-[122.247px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 123 71">
        <g id="Group 14291">
          <path d={svgPaths.p3c43b180} fill="var(--fill-0, #FECA00)" id="Vector" />
          <path d={svgPaths.p3e13e780} fill="var(--fill-0, white)" id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="4" />
          <path d={svgPaths.p7656680} fill="var(--fill-0, #FECA00)" id="Vector_3" />
          <path d={svgPaths.p34f57600} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="4" />
          <path d={svgPaths.p5b53e00} fill="var(--fill-0, #FECA00)" id="Vector_5" />
          <path d={svgPaths.pb879c00} fill="var(--fill-0, white)" id="Vector_6" stroke="var(--stroke-0, white)" strokeWidth="4" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-0 top-0">
      <div className="absolute h-[127px] left-0 top-0 w-[162px]">
        <div aria-hidden="true" className="absolute border-4 border-solid border-white inset-0 pointer-events-none" />
      </div>
      <Group1 />
    </div>
  );
}

function Logo() {
  return (
    <div className="h-[127px] relative shrink-0 w-[162px]" data-name="Logo">
      <Group2 />
    </div>
  );
}

function Frame45() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-col items-center size-full">
        <div className="box-border content-stretch flex flex-col gap-[10px] items-center p-[36px] relative w-full">
          <Logo />
        </div>
      </div>
    </div>
  );
}

function IconsBrand() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path d={svgPaths.pc3dbd00} fill="var(--fill-0, white)" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="21.3333" />
        </g>
      </svg>
    </div>
  );
}

function NavItem() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">Dashboard</p>
        </div>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[4.17%_12.22%_4.17%_8.33%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 19">
        <g id="Group 14288">
          <path d={svgPaths.p16c11e00} fill="var(--fill-0, #FECA00)" id="Vector" stroke="var(--stroke-0, #FECA00)" strokeWidth="16" />
          <path d={svgPaths.p1071c900} fill="var(--fill-0, #FECA00)" id="Vector_2" />
          <path d={svgPaths.p6432400} fill="var(--fill-0, #FECA00)" id="Vector_3" />
          <path d={svgPaths.p18d51980} fill="var(--fill-0, #FECA00)" id="Vector_4" />
          <path d={svgPaths.p2427ee00} fill="var(--fill-0, #FECA00)" id="Vector_5" />
          <path d={svgPaths.p8975b40} fill="var(--fill-0, #FECA00)" id="Vector_6" />
          <path d={svgPaths.p1a5ba900} fill="var(--fill-0, #FECA00)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function IconsBrand1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <Group />
    </div>
  );
}

function NavItem1() {
  return (
    <div className="bg-[rgba(255,255,255,0.1)] h-[56px] relative shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand1 />
          <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] relative shrink-0 text-[14px] text-nowrap text-white whitespace-pre">Tenders</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path d={svgPaths.p26d3c800} fill="var(--fill-0, white)" id="Vector" stroke="var(--stroke-0, white)" />
        </g>
      </svg>
    </div>
  );
}

function NavItem2() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand2 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">Projects</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path d={svgPaths.p75e63b0} fill="var(--fill-0, white)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function NavItem3() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand3 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">{`Health & Safety`}</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path clipRule="evenodd" d={svgPaths.p16c7db00} fill="var(--fill-0, white)" fillRule="evenodd" id="path1998 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.pa20e580} fill="var(--fill-0, white)" fillRule="evenodd" id="path2002 (Stroke)" />
          <path d={svgPaths.p1f527600} fill="var(--fill-0, white)" id="path2006" />
          <path d={svgPaths.p2f95c700} fill="var(--fill-0, white)" id="path2010" />
          <path d={svgPaths.p4032df0} fill="var(--fill-0, white)" id="path2014" />
          <path d={svgPaths.p3eebe300} fill="var(--fill-0, white)" id="path2018" />
          <path clipRule="evenodd" d={svgPaths.p217b1400} fill="var(--fill-0, white)" fillRule="evenodd" id="path2022 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p1f3a0d00} fill="var(--fill-0, white)" fillRule="evenodd" id="path2026 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p10c5e340} fill="var(--fill-0, white)" fillRule="evenodd" id="path2030 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p365e2800} fill="var(--fill-0, white)" fillRule="evenodd" id="path2034 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p1de96790} fill="var(--fill-0, white)" fillRule="evenodd" id="path2038 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p12868780} fill="var(--fill-0, white)" fillRule="evenodd" id="path2042 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p1d81c440} fill="var(--fill-0, white)" fillRule="evenodd" id="path2046 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p29455200} fill="var(--fill-0, white)" fillRule="evenodd" id="path2050 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p345df980} fill="var(--fill-0, white)" fillRule="evenodd" id="path2054 (Stroke)" />
          <path clipRule="evenodd" d={svgPaths.p19e1ee80} fill="var(--fill-0, white)" fillRule="evenodd" id="path2058 (Stroke)" />
        </g>
      </svg>
    </div>
  );
}

function NavItem4() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand4 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">Equipment</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <g id="Vector">
            <mask fill="white" id="path-1-inside-1_1_6846">
              <path d={svgPaths.p12ed5b80} />
            </mask>
            <path d={svgPaths.p12ed5b80} fill="var(--fill-0, white)" />
            <path d={svgPaths.p22e00900} fill="var(--stroke-0, white)" mask="url(#path-1-inside-1_1_6846)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function NavItem5() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand5 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">Vehicles</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path d={svgPaths.p5a0a600} fill="var(--fill-0, white)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function NavItem6() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand6 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">Emissions</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path d={svgPaths.p26aeb900} fill="var(--fill-0, white)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function NavItem7() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsBrand7 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">Accounts</p>
        </div>
      </div>
    </div>
  );
}

function IconsBrand8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Brand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icons/Brand">
          <path d={svgPaths.p2f555200} fill="var(--fill-0, white)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function NavItem8() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="size-full">
        <div className="box-border content-stretch flex gap-[8px] items-start px-[28px] py-[16px] relative size-full">
          <IconsBrand8 />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-nowrap text-white whitespace-pre">HR</p>
        </div>
      </div>
    </div>
  );
}

function IconsIconLibrary() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_6829)" id="Icons/Icon library">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M10 14.1667H10.0083" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p22540600} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_1_6829">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function NavItem9() {
  return (
    <div className="h-[56px] relative rounded-[4px] shrink-0 w-full" data-name="Nav item">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[56px] items-center px-[28px] py-[16px] relative w-full">
          <IconsIconLibrary />
          <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-white w-[148px]">{`Help & support`}</p>
        </div>
      </div>
    </div>
  );
}

function Frame44() {
  return (
    <div className="basis-0 box-border content-stretch flex flex-col grow items-start min-h-px min-w-px pb-[28px] pt-0 px-0 relative shrink-0 w-full">
      <NavItem />
      <NavItem1 />
      <NavItem2 />
      <NavItem3 />
      <NavItem4 />
      <NavItem5 />
      <NavItem6 />
      <NavItem7 />
      <NavItem8 />
      <NavItem9 />
    </div>
  );
}

function SideNavigation() {
  return (
    <div className="bg-[#0d2352] content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[240px]" data-name="Side navigation">
      <Frame45 />
      <Frame44 />
    </div>
  );
}

function Iconography() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Iconography">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Iconography">
          <path d={svgPaths.p2f9b7500} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function InputText() {
  return (
    <div className="basis-0 content-stretch flex grow items-center min-h-px min-w-px relative shrink-0" data-name="input-text">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5d5d5c] text-[16px] text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[24px] whitespace-pre">Search</p>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[12px] h-full items-center relative shrink-0 w-[826px]">
      <Iconography />
      <InputText />
    </div>
  );
}

function StateLayer() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative rounded-tl-[4px] rounded-tr-[4px] shrink-0 w-full" data-name="state-layer">
      <div className="size-full">
        <div className="box-border content-stretch flex items-start px-[16px] py-[4px] relative size-full">
          <Frame1 />
        </div>
      </div>
    </div>
  );
}

function TextField() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start relative rounded-[20px] shrink-0 w-[302px]" data-name="Text field">
      <div aria-hidden="true" className="absolute border border-[#bbc9ce] border-solid inset-[-0.5px] pointer-events-none rounded-[20.5px]" />
      <StateLayer />
    </div>
  );
}

function IconsIconLibrary1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icons/Icon library">
          <path d={svgPaths.p1e4b7b80} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p146fda80} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function IconsIconLibrary2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icons/Icon library">
          <path d={svgPaths.p82039c0} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p2c19cb00} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function IconsIconLibrary3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_6819)" id="Icons/Icon library">
          <path d={svgPaths.p3cccb600} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.pdd91970} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_1_6819">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame46() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <IconsIconLibrary1 />
      <IconsIconLibrary2 />
      <IconsIconLibrary3 />
    </div>
  );
}

function Avatars() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Avatars">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <circle cx="12" cy="12" fill="var(--fill-0, #FF7677)" id="Circle" r="12" />
      </svg>
      <div className="absolute flex flex-col font-['Roboto:Bold',sans-serif] font-bold inset-0 justify-center leading-[0] text-[16px] text-black text-center uppercase" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[24px]">A</p>
      </div>
    </div>
  );
}

function UserNavButton() {
  return (
    <div className="box-border content-stretch flex gap-[8px] h-[48px] items-center px-[16px] py-0 relative rounded-[30px] shrink-0" data-name="User nav button">
      <div aria-hidden="true" className="absolute border border-[#d0d0d0] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <Avatars />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black text-nowrap">
        <p className="leading-[28px] whitespace-pre">Alex Conner</p>
      </div>
    </div>
  );
}

function Selected() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative rounded-[68px] shrink-0" data-name="Selected">
      <Frame46 />
      <UserNavButton />
    </div>
  );
}

function MastHeader() {
  return (
    <div className="bg-white box-border content-stretch flex items-center justify-between px-[20px] py-[16px] relative shrink-0 w-[1200px]" data-name="Mast header">
      <div className="flex flex-row items-center self-stretch">
        <TextField />
      </div>
      <Selected />
    </div>
  );
}

function IconsIconLibrary4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icons/Icon library">
          <path d="M19 12H5" id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M12 19L5 12L12 5" id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function TextLink() {
  return (
    <button className="box-border content-stretch cursor-pointer flex gap-[4px] items-center p-0 relative shrink-0" data-name="Text link">
      <IconsIconLibrary4 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] relative shrink-0 text-[14px] text-black text-nowrap whitespace-pre">Back to Tenders</p>
    </button>
  );
}

function Chips() {
  return (
    <div className="bg-red-100 box-border content-stretch flex gap-[10px] items-center px-[12px] py-[6px] relative rounded-[3px] shrink-0" data-name="chips">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] relative shrink-0 text-[14px] text-nowrap text-red-900 whitespace-pre">Unsuccessful</p>
    </div>
  );
}

function StatusChips() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="status chips">
      <Chips />
    </div>
  );
}

function Frame41() {
  return (
    <div className="basis-0 content-stretch flex gap-[12px] grow items-center min-h-px min-w-px relative shrink-0">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[48px] relative shrink-0 text-[40px] text-black text-nowrap whitespace-pre">DDA Works</p>
      <StatusChips />
    </div>
  );
}

function Button() {
  return (
    <div className="box-border content-stretch flex gap-[4px] items-center justify-center px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#d0d0d0] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[28px] relative shrink-0 text-[#5d5d5c] text-[16px] text-center text-nowrap whitespace-pre">Add feedback</p>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full">
      <Frame41 />
      <Button />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame11 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] relative shrink-0 text-[#61828d] text-[20px] w-full">Central Bedfordshire Council</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <TextLink />
      <Frame12 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] min-w-full relative shrink-0 text-[#61828d] text-[12px] w-[min-content]">Reference number</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[28px] relative shrink-0 text-[16px] text-nowrap text-slate-900 whitespace-pre">CBC-1620-T-TS</p>
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] min-w-full relative shrink-0 text-[#61828d] text-[12px] w-[min-content]">Created by</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[28px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre">Rob Hutchinson</p>
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] min-w-full relative shrink-0 text-[#61828d] text-[12px] w-[min-content]">Assigned to</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[28px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre">Alex Conner</p>
    </div>
  );
}

function DueFlags() {
  return (
    <div className="h-[16px] relative shrink-0 w-[85px]" data-name="Due flags">
      <p className="absolute font-['Poppins:Medium',sans-serif] inset-0 leading-[16px] not-italic text-[#0ad6a1] text-[12px] text-nowrap whitespace-pre">Due in 31 days</p>
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[28px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre">02/08/24</p>
      <DueFlags />
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#61828d] text-[12px] text-nowrap whitespace-pre">Submission due date</p>
      <Frame30 />
    </div>
  );
}

function Frame31() {
  return (
    <div className="content-stretch flex gap-[44px] items-center relative shrink-0">
      <Frame26 />
      <Frame29 />
      <Frame27 />
      <Frame28 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col gap-[28px] items-start relative shrink-0 w-full">
      <Frame9 />
      <Frame31 />
    </div>
  );
}

function SectionHeaders() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[28px] items-start px-[28px] py-[32px] relative shrink-0 w-[1200px]" data-name="Section headers">
      <div aria-hidden="true" className="absolute border-[#bbc9ce] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Frame8 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center px-[12px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[16px] text-black text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[24px] whitespace-pre">Tender details</p>
      </div>
    </div>
  );
}

function SecondaryNavItem() {
  return (
    <div className="bg-[#fbfbfb] box-border content-stretch flex flex-col gap-[10px] items-start px-[12px] py-[10px] relative rounded-tl-[4px] rounded-tr-[4px] shrink-0" data-name="Secondary nav item">
      <div aria-hidden="true" className="absolute border-[#d0d0d0] border-[0px_0px_1px] border-solid inset-0 pointer-events-none rounded-tl-[4px] rounded-tr-[4px]" />
      <Frame4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center px-[12px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center text-nowrap">
        <p className="leading-[24px] whitespace-pre">Submitted documents</p>
      </div>
    </div>
  );
}

function SecondaryNavItem1() {
  return (
    <div className="bg-[#fbfbfb] box-border content-stretch flex flex-col gap-[10px] h-full items-start px-[12px] py-[10px] relative rounded-tl-[4px] rounded-tr-[4px] shrink-0" data-name="Secondary nav item">
      <div aria-hidden="true" className="absolute border-[#d0d0d0] border-[0px_0px_1px] border-solid inset-0 pointer-events-none rounded-tl-[4px] rounded-tr-[4px]" />
      <Frame5 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center px-[12px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center text-nowrap">
        <p className="leading-[24px] whitespace-pre">Feedback scores</p>
      </div>
    </div>
  );
}

function SecondaryNavItem2() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[10px] items-start px-[12px] py-[10px] relative rounded-tl-[4px] rounded-tr-[4px] shrink-0" data-name="Secondary nav item">
      <div aria-hidden="true" className="absolute border-[#d0d0d0] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[4px] rounded-tr-[4px]" />
      <Frame6 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center px-[12px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center text-nowrap">
        <p className="leading-[24px] whitespace-pre">Activity log</p>
      </div>
    </div>
  );
}

function SecondaryNavItem3() {
  return (
    <div className="bg-[#fbfbfb] box-border content-stretch flex flex-col gap-[10px] items-start px-[12px] py-[10px] relative rounded-tl-[4px] rounded-tr-[4px] shrink-0" data-name="Secondary nav item">
      <div aria-hidden="true" className="absolute border-[#d0d0d0] border-[0px_0px_1px] border-solid inset-0 pointer-events-none rounded-tl-[4px] rounded-tr-[4px]" />
      <Frame7 />
    </div>
  );
}

function SecondaryNav() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Secondary nav">
      <SecondaryNavItem />
      <div className="flex flex-row items-center self-stretch">
        <SecondaryNavItem1 />
      </div>
      <SecondaryNavItem2 />
      <SecondaryNavItem3 />
    </div>
  );
}

function HorizontalTabs() {
  return (
    <div className="content-stretch flex gap-[36px] items-start relative shrink-0 w-full" data-name="Horizontal tabs">
      <div aria-hidden="true" className="absolute border-[#d0d0d0] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <SecondaryNav />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] items-center justify-center px-[16px] py-[8px] relative rounded-[6px] shrink-0" data-name="button">
      <div aria-hidden="true" className="absolute border border-slate-200 border-solid inset-0 pointer-events-none rounded-[6px]" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[14px] text-nowrap text-slate-900 whitespace-pre">Edit feedback</p>
    </div>
  );
}

function Frame3() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[10px] items-end mb-[-40px] relative shrink-0 w-full">
      <Button1 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] h-[24px] items-start relative shrink-0">
      <div className="flex flex-col font-['Montserrat:Bold',sans-serif] font-bold h-[25px] justify-center leading-[0] opacity-80 relative shrink-0 text-[#2d6a79] text-[12px] w-[280px]">
        <p className="leading-[16px]">Client Contact Details</p>
      </div>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-[784px]">
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[28px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre">
        Jonathan Rogers
        <br aria-hidden="true" />
        0300 300 5431
        <br aria-hidden="true" />
        jonathan.rogers@centralbedfordshire.gov.uk
      </p>
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex gap-[24px] items-start relative shrink-0 w-full">
      <Frame15 />
      <Frame18 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] h-[24px] items-start relative shrink-0">
      <div className="flex flex-col font-['Montserrat:Bold',sans-serif] font-bold h-[23px] justify-center leading-[0] opacity-80 relative shrink-0 text-[#2d6a79] text-[12px] w-[280px]">
        <p className="leading-[16px]">Comments</p>
      </div>
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0">
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[14px] text-black w-[750px]">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
    </div>
  );
}

function Frame17() {
  return (
    <div className="box-border content-stretch flex gap-[24px] h-[72px] items-start pb-[48px] pt-0 px-0 relative shrink-0">
      <Frame16 />
      <Frame21 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] h-[24px] items-start justify-center relative shrink-0">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] opacity-80 relative shrink-0 text-[#2d6a79] text-[12px] w-[280px]">Supplied documents</p>
    </div>
  );
}

function FileIcons() {
  return (
    <div className="h-[49px] relative shrink-0 w-[44px]" data-name="File icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44 49">
        <g id="File icons">
          <mask height="49" id="mask0_1_6908" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="44" x="0" y="0">
            <path d={svgPaths.p3be5f1f0} fill="url(#paint0_linear_1_6908)" id="Rectangle 4" />
          </mask>
          <g mask="url(#mask0_1_6908)">
            <g id="Group 4">
              <path d={svgPaths.p3be5f1f0} fill="url(#paint1_linear_1_6908)" id="Rectangle 6" />
              <g id="PDF">
                <path d={svgPaths.pd62fb30} fill="var(--fill-0, white)" id="Vector" />
                <path d={svgPaths.p3ae78d00} fill="var(--fill-0, white)" id="Vector_2" />
                <path d={svgPaths.p159fba00} fill="var(--fill-0, white)" id="Vector_3" />
              </g>
              <g id="PDF (Stroke)">
                <path clipRule="evenodd" d={svgPaths.p2e77db00} fill="var(--fill-0, white)" fillRule="evenodd" id="Stroke" />
                <path clipRule="evenodd" d={svgPaths.pd9a900} fill="var(--fill-0, white)" fillRule="evenodd" id="Stroke_2" />
                <path clipRule="evenodd" d={svgPaths.p13e4cf80} fill="var(--fill-0, white)" fillRule="evenodd" id="Stroke_3" />
              </g>
              <g filter="url(#filter0_d_1_6908)" id="Rectangle 5">
                <path d={svgPaths.p18934300} fill="url(#paint2_linear_1_6908)" />
              </g>
            </g>
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="66.2273" id="filter0_d_1_6908" width="66.5" x="4.5" y="-24">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dx="2" dy="1" />
            <feGaussianBlur stdDeviation="12.5" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.33 0" />
            <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_6908" />
            <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_6908" mode="normal" result="shape" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_6908" x1="22" x2="22" y1="0" y2="49">
            <stop stopColor="#FF7979" />
            <stop offset="1" stopColor="#E85555" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_6908" x1="22" x2="22" y1="0" y2="49">
            <stop stopColor="#FF7981" />
            <stop offset="1" stopColor="#E85567" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint2_linear_1_6908" x1="35.75" x2="35.75" y1="0" y2="16.2273">
            <stop stopColor="#D03954" />
            <stop offset="1" stopColor="#C02A3C" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function IconsIconLibrary5() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icons/Icon library">
          <path d={svgPaths.p3f80dc40} id="Vector" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M20 8V14" id="Vector_2" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M23 11H17" id="Vector_3" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p1280af80} id="Vector_4" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function IconsIconLibrary6() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icons/Icon library">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icons/Icon library">
          <path d={svgPaths.p2d557600} id="Vector" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M7 10L12 15L17 10" id="Vector_2" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M12 15V3" id="Vector_3" stroke="var(--stroke-0, #4B707C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function UploadedDocCard() {
  return (
    <div className="bg-white relative rounded-[4px] shrink-0 w-full" data-name="Uploaded doc card">
      <div aria-hidden="true" className="absolute border border-[#d2dbde] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] items-center p-[12px] relative w-full">
          <FileIcons />
          <p className="basis-0 font-['Montserrat:Regular',sans-serif] font-normal grow leading-[28px] min-h-px min-w-px relative shrink-0 text-[16px] text-black">{`PT31 - Unsuccessful Quotation G&S.PDF`}</p>
          <IconsIconLibrary5 />
          <IconsIconLibrary6 />
        </div>
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[14px] items-end relative shrink-0 w-[760px]">
      <UploadedDocCard />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex gap-[24px] items-start relative shrink-0">
      <Frame23 />
      <Frame13 />
    </div>
  );
}

function Frame48() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[24px] items-start mb-[-40px] relative shrink-0 w-full">
      <Frame19 />
      <Frame17 />
      <Frame14 />
    </div>
  );
}

function Frame22() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-[40px] pt-0 px-[28px] relative w-full">
          <Frame3 />
          <Frame48 />
        </div>
      </div>
    </div>
  );
}

function TableHeaderCell() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0 w-[220px]" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">Evaluation</p>
    </div>
  );
}

function TableHeaderCell1() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">Weighting</p>
    </div>
  );
}

function TableHeaderCell2() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0 w-[54px]" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">{`A (G&S)`}</p>
    </div>
  );
}

function TableHeaderCell3() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0 w-[54px]" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">B</p>
    </div>
  );
}

function TableHeaderCell4() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0 w-[54px]" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">C</p>
    </div>
  );
}

function TableHeaderCell5() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0 w-[54px]" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">D</p>
    </div>
  );
}

function TableHeaderCell6() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[44px] items-center px-0 py-[16px] relative shrink-0 w-[54px]" data-name="Table header cell">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-black text-nowrap whitespace-pre">E</p>
    </div>
  );
}

function TableHeader() {
  return (
    <div className="bg-[#fbfbfb] h-[64px] relative shrink-0 w-full" data-name="Table Header">
      <div aria-hidden="true" className="absolute border-[#b8b8b7] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex h-[64px] items-center justify-between px-[20px] py-0 relative w-full">
          <TableHeaderCell />
          <TableHeaderCell1 />
          <TableHeaderCell2 />
          <TableHeaderCell3 />
          <TableHeaderCell4 />
          <TableHeaderCell5 />
          <TableHeaderCell6 />
        </div>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Financial Evaluation
      </p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[220px]">
      <Content />
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60%
      </p>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[65px]">
      <Content1 />
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0%
      </p>
    </div>
  );
}

function Frame25() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[54px]">
      <Content2 />
    </div>
  );
}

function TableRow() {
  return (
    <div className="bg-white h-[72px] relative shrink-0 w-full" data-name="Table Row">
      <div aria-hidden="true" className="absolute border-[#b8b8b7] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex h-[72px] items-center justify-between px-[20px] py-[12px] relative w-full">
          <Frame10 />
          <Frame24 />
          {[...Array(5).keys()].map((_, i) => (
            <Frame25 key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start justify-center min-h-px min-w-px relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] min-w-full relative shrink-0 text-[16px] text-black w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Quality and services delivery evalutaion
      </p>
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[220px]">
      <Content3 />
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40%
      </p>
    </div>
  );
}

function Frame33() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[65px]">
      <Content4 />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0%
      </p>
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[54px]">
      <Content5 />
    </div>
  );
}

function TableRow1() {
  return (
    <div className="bg-white h-[72px] relative shrink-0 w-full" data-name="Table Row">
      <div aria-hidden="true" className="absolute border-[#b8b8b7] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex h-[72px] items-center justify-between px-[20px] py-[12px] relative w-full">
          <Frame32 />
          <Frame33 />
          {[...Array(5).keys()].map((_, i) => (
            <Frame34 key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start justify-center min-h-px min-w-px relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Bold',sans-serif] font-bold leading-[24px] min-w-full relative shrink-0 text-[16px] text-black w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Total awarded
      </p>
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[220px]">
      <Content6 />
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Bold',sans-serif] font-bold leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100%
      </p>
    </div>
  );
}

function Frame36() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[65px]">
      <Content7 />
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0%
      </p>
    </div>
  );
}

function Frame37() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[54px]">
      <Content8 />
    </div>
  );
}

function TableRow2() {
  return (
    <div className="bg-white h-[72px] relative shrink-0 w-full" data-name="Table Row">
      <div aria-hidden="true" className="absolute border-[#b8b8b7] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex h-[72px] items-center justify-between px-[20px] py-[12px] relative w-full">
          <Frame35 />
          <Frame36 />
          {[...Array(5).keys()].map((_, i) => (
            <Frame37 key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Content9() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start justify-center min-h-px min-w-px relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Bold',sans-serif] font-bold leading-[24px] min-w-full relative shrink-0 text-[16px] text-black w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Ranking
      </p>
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[220px]">
      <Content9 />
    </div>
  );
}

function Content10() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        {" "}
      </p>
    </div>
  );
}

function Frame39() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[65px]">
      <Content10 />
    </div>
  );
}

function Content11() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Content">
      <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[16px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        -
      </p>
    </div>
  );
}

function Frame40() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[54px]">
      <Content11 />
    </div>
  );
}

function TableRow3() {
  return (
    <div className="h-[72px] relative shrink-0 w-full" data-name="Table Row">
      <div aria-hidden="true" className="absolute border-[#b8b8b7] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex h-[72px] items-center justify-between px-[20px] py-[12px] relative w-full">
          <Frame38 />
          <Frame39 />
          {[...Array(5).keys()].map((_, i) => (
            <Frame40 key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start px-px py-0 relative w-full">
          <TableHeader />
          <TableRow />
          <TableRow1 />
          <TableRow2 />
          <TableRow3 />
        </div>
      </div>
    </div>
  );
}

function Frame47() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[12px] items-start px-[28px] py-0 relative w-full">
          <Frame2 />
        </div>
      </div>
    </div>
  );
}

function Frame42() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[36px] items-start px-0 py-[48px] relative shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#d0d0d0] border-[0px_1px_1px] border-solid inset-0 pointer-events-none" />
      <Frame22 />
      <Frame47 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col items-start relative rounded-[8px] shrink-0 w-full">
      <HorizontalTabs />
      <Frame42 />
    </div>
  );
}

function Frame() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[28px] items-start p-[28px] relative shrink-0 w-[1200px]">
      <Frame20 />
    </div>
  );
}

function Frame43() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame />
    </div>
  );
}

function Frame49() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1200px]">
      <MastHeader />
      <SectionHeaders />
      <Frame43 />
    </div>
  );
}

export default function TendersFeedbackDashboard() {
  return (
    <div className="bg-[#f1f0ee] content-stretch flex items-start relative size-full" data-name="Tenders - ashwell gate">
      <SideNavigation />
      <Frame49 />
    </div>
  );
}